"""Superpipe"""

from .superpipe import pipes
from .utils import cube, foreach, is_even, is_falsy, is_none, is_not_none, is_odd, is_truthy, square
